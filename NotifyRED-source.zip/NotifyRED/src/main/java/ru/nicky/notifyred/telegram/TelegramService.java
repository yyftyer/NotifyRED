package ru.nicky.notifyred.telegram;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;
import java.security.SecureRandom;

public final class TelegramService {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final long LINK_CODE_LIFETIME_MS = Duration.ofMinutes(5).toMillis();

    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static final Map<UUID, String> LINKED_CHATS = new ConcurrentHashMap<>();
    private static final Map<String, PendingLink> PENDING_CODES = new ConcurrentHashMap<>();

    private static volatile String botToken = "";
    private static volatile JsonObject configRoot = new JsonObject();
    private static volatile HttpClient httpClient;
    private static volatile ExecutorService pollExecutor;
    private static volatile ExecutorService sendExecutor;

    private TelegramService() {
    }

    public static void onServerStarted(ServerStartedEvent event) {
        start();
    }

    public static void onServerStopped(ServerStoppedEvent event) {
        stop();
    }

    private static synchronized void start() {
        stop();
        try {
            loadConfig();
        } catch (Exception exception) {
            LOGGER.error("NotifyRED: не удалось прочитать config/notifyred.json", exception);
            return;
        }

        if (botToken.isBlank()) {
            LOGGER.warn("NotifyRED: botToken не задан. Открой config/notifyred.json, впиши токен Telegram-бота и перезапусти сервер.");
            return;
        }

        httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        pollExecutor = Executors.newSingleThreadExecutor(namedThread("NotifyRED-Telegram-Poll"));
        sendExecutor = Executors.newFixedThreadPool(2, namedThread("NotifyRED-Telegram-Send"));
        RUNNING.set(true);
        pollExecutor.submit(TelegramService::pollLoop);
        LOGGER.info("NotifyRED: Telegram polling запущен.");
    }

    private static synchronized void stop() {
        RUNNING.set(false);
        if (pollExecutor != null) {
            pollExecutor.shutdownNow();
            pollExecutor = null;
        }
        if (sendExecutor != null) {
            sendExecutor.shutdown();
            sendExecutor = null;
        }
        PENDING_CODES.clear();
    }

    private static ThreadFactory namedThread(String name) {
        return runnable -> {
            Thread thread = new Thread(runnable, name);
            thread.setDaemon(true);
            return thread;
        };
    }

    private static synchronized void loadConfig() throws IOException {
        Path configPath = FMLPaths.CONFIGDIR.get().resolve("notifyred.json");
        Files.createDirectories(configPath.getParent());

        if (Files.notExists(configPath)) {
            JsonObject freshConfig = new JsonObject();
            freshConfig.addProperty("botToken", "");
            freshConfig.add("linkedChats", new JsonObject());
            Files.writeString(configPath, GSON.toJson(freshConfig));
        }

        JsonElement parsed = JsonParser.parseString(Files.readString(configPath));
        if (!parsed.isJsonObject()) {
            throw new IOException("Файл notifyred.json должен содержать JSON-объект.");
        }

        configRoot = parsed.getAsJsonObject();
        botToken = configRoot.has("botToken") && !configRoot.get("botToken").isJsonNull()
                ? configRoot.get("botToken").getAsString().trim()
                : "";

        LINKED_CHATS.clear();
        if (configRoot.has("linkedChats") && configRoot.get("linkedChats").isJsonObject()) {
            JsonObject savedLinks = configRoot.getAsJsonObject("linkedChats");
            for (Map.Entry<String, JsonElement> entry : savedLinks.entrySet()) {
                try {
                    UUID playerId = UUID.fromString(entry.getKey());
                    String chatId = entry.getValue().getAsString();
                    if (!chatId.isBlank()) {
                        LINKED_CHATS.put(playerId, chatId);
                    }
                } catch (RuntimeException ignored) {
                    LOGGER.warn("NotifyRED: пропускаю некорректную запись привязки {}.", entry.getKey());
                }
            }
        }
    }

    private static synchronized void saveConfig() {
        try {
            JsonObject savedLinks = new JsonObject();
            LINKED_CHATS.forEach((playerId, chatId) -> savedLinks.addProperty(playerId.toString(), chatId));
            configRoot.add("linkedChats", savedLinks);

            Path configPath = FMLPaths.CONFIGDIR.get().resolve("notifyred.json");
            Files.createDirectories(configPath.getParent());
            Files.writeString(configPath, GSON.toJson(configRoot));
        } catch (IOException exception) {
            LOGGER.error("NotifyRED: не удалось сохранить привязки Telegram.", exception);
        }
    }

    /** Returns null when the bot is not configured or polling is not running. */
    public static String createLinkCode(UUID playerId) {
        if (!RUNNING.get() || botToken.isBlank()) {
            return null;
        }

        long now = System.currentTimeMillis();
        PENDING_CODES.entrySet().removeIf(entry -> entry.getValue().expiresAtMs() < now);

        String code;
        do {
            code = String.format(Locale.ROOT, "%08d", RANDOM.nextInt(100_000_000));
        } while (PENDING_CODES.containsKey(code));

        PENDING_CODES.put(code, new PendingLink(playerId, now + LINK_CODE_LIFETIME_MS));
        return code;
    }

    public static boolean isLinked(UUID playerId) {
        return LINKED_CHATS.containsKey(playerId);
    }

    public static boolean unlink(UUID playerId) {
        boolean removed = LINKED_CHATS.remove(playerId) != null;
        if (removed) {
            saveConfig();
        }
        return removed;
    }

    public static void sendActivation(ServerLevel level, BlockPos pos, UUID ownerId) {
        String chatId = LINKED_CHATS.get(ownerId);
        ExecutorService executor = sendExecutor;
        if (chatId == null || executor == null || executor.isShutdown() || !RUNNING.get()) {
            return;
        }

        String onlinePlayers = level.getServer().getPlayerList().getPlayers().stream()
                .map(ServerPlayer::getGameProfile)
                .map(profile -> profile.getName())
                .reduce((left, right) -> left + ", " + right)
                .orElse("никого");

        String time = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss z", Locale.ROOT));
        String message = "🚨 NotifyRED: редстоун-сигнал получен!\n"
                + "Время: " + time + "\n"
                + "Мир: " + level.dimension().location() + "\n"
                + "Координаты: " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + "\n"
                + "Игроки онлайн: " + onlinePlayers;

        executor.submit(() -> sendTelegramMessage(chatId, message));
    }

    private static void pollLoop() {
        long nextOffset = 0L;
        while (RUNNING.get()) {
            try {
                URI uri = URI.create(apiUrl("getUpdates")
                        + "?timeout=20&offset=" + nextOffset
                        + "&allowed_updates=%5B%22message%22%5D");
                HttpRequest request = HttpRequest.newBuilder(uri)
                        .timeout(Duration.ofSeconds(30))
                        .GET()
                        .build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
                if (!root.has("ok") || !root.get("ok").getAsBoolean()) {
                    String description = root.has("description") ? root.get("description").getAsString() : "unknown error";
                    throw new IOException("Telegram getUpdates: " + description);
                }

                JsonArray updates = root.getAsJsonArray("result");
                for (JsonElement element : updates) {
                    JsonObject update = element.getAsJsonObject();
                    if (update.has("update_id")) {
                        nextOffset = Math.max(nextOffset, update.get("update_id").getAsLong() + 1L);
                    }
                    handleTelegramUpdate(update);
                }
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception exception) {
                if (RUNNING.get()) {
                    LOGGER.warn("NotifyRED: ошибка связи с Telegram: {}", exception.getMessage());
                    try {
                        Thread.sleep(3000L);
                    } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }
    }

    private static void handleTelegramUpdate(JsonObject update) {
        if (!update.has("message") || !update.get("message").isJsonObject()) {
            return;
        }

        JsonObject message = update.getAsJsonObject("message");
        if (!message.has("text") || !message.has("chat") || !message.get("chat").isJsonObject()) {
            return;
        }

        JsonObject chat = message.getAsJsonObject("chat");
        if (chat.has("type") && !"private".equals(chat.get("type").getAsString())) {
            return;
        }

        String text = message.get("text").getAsString().trim();
        String[] parts = text.split("\\s+", 2);
        String command = parts[0];
        if (!command.equals("/start") && !command.startsWith("/start@")) {
            return;
        }

        String chatId = chat.get("id").getAsString();
        if (parts.length < 2 || parts[1].isBlank()) {
            queueTelegramMessage(chatId, "Чтобы привязать Minecraft-профиль, введи в игре /notifyred link, а затем отправь сюда /start КОД.");
            return;
        }

        String code = parts[1].trim().split("\\s+")[0];
        PendingLink pending = PENDING_CODES.remove(code);
        if (pending == null || pending.expiresAtMs() < System.currentTimeMillis()) {
            queueTelegramMessage(chatId, "Код не найден или уже истёк. Получи новый командой /notifyred link в Minecraft.");
            return;
        }

        LINKED_CHATS.put(pending.playerId(), chatId);
        saveConfig();
        queueTelegramMessage(chatId, "✅ Telegram успешно привязан к твоему Minecraft-профилю! Теперь уведомления будут приходить, когда твой NotifyRED-блок получит редстоун-сигнал.");
        LOGGER.info("NotifyRED: Telegram-чат привязан к Minecraft UUID {}.", pending.playerId());
    }

    private static void queueTelegramMessage(String chatId, String text) {
        ExecutorService executor = sendExecutor;
        if (executor != null && !executor.isShutdown()) {
            executor.submit(() -> sendTelegramMessage(chatId, text));
        }
    }

    private static void sendTelegramMessage(String chatId, String text) {
        try {
            JsonObject payload = new JsonObject();
            payload.addProperty("chat_id", chatId);
            payload.addProperty("text", text);

            HttpRequest request = HttpRequest.newBuilder(URI.create(apiUrl("sendMessage")))
                    .timeout(Duration.ofSeconds(15))
                    .header("Content-Type", "application/json; charset=UTF-8")
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload)))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject result = JsonParser.parseString(response.body()).getAsJsonObject();
            if (response.statusCode() / 100 != 2 || !result.has("ok") || !result.get("ok").getAsBoolean()) {
                String description = result.has("description") ? result.get("description").getAsString() : response.body();
                LOGGER.warn("NotifyRED: Telegram не принял сообщение: {}", description);
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        } catch (Exception exception) {
            LOGGER.warn("NotifyRED: не удалось отправить сообщение в Telegram: {}", exception.getMessage());
        }
    }

    private static String apiUrl(String method) {
        return "https://api.telegram.org/bot" + botToken + "/" + method;
    }

    private record PendingLink(UUID playerId, long expiresAtMs) {
    }
}
