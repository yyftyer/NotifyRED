package ru.nicky.notifyred;

import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import ru.nicky.notifyred.block.ModBlockEntities;
import ru.nicky.notifyred.block.ModBlocks;
import ru.nicky.notifyred.command.NotifyCommands;
import ru.nicky.notifyred.telegram.TelegramService;

@Mod(NotifyRED.MOD_ID)
public final class NotifyRED {
    public static final String MOD_ID = "notifyred";

    public NotifyRED(IEventBus modEventBus) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModBlocks.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITY_TYPES.register(modEventBus);

        modEventBus.addListener(this::addCreative);

        NeoForge.EVENT_BUS.addListener(NotifyCommands::register);
        NeoForge.EVENT_BUS.addListener(TelegramService::onServerStarted);
        NeoForge.EVENT_BUS.addListener(TelegramService::onServerStopped);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(ModBlocks.REDSTONE_NOTIFY_ITEM);
        }
    }
}
