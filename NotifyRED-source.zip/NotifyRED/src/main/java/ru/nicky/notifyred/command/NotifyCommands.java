package ru.nicky.notifyred.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import ru.nicky.notifyred.telegram.TelegramService;

public final class NotifyCommands {
    private NotifyCommands() {
    }

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("notifyred")
                .then(Commands.literal("link").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    String code = TelegramService.createLinkCode(player.getUUID());
                    if (code == null) {
                        context.getSource().sendFailure(Component.literal(
                                "NotifyRED: бот не настроен. Укажи botToken в config/notifyred.json и перезапусти сервер."
                        ));
                        return 0;
                    }

                    context.getSource().sendSuccess(() -> Component.literal(
                            "Код привязки: " + code + "\nОткрой личный чат со своим Telegram-ботом и отправь ему: /start " + code
                                    + "\nКод действует 5 минут."
                    ), false);
                    return 1;
                }))
                .then(Commands.literal("unlink").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    boolean removed = TelegramService.unlink(player.getUUID());
                    context.getSource().sendSuccess(() -> Component.literal(
                            removed ? "NotifyRED: Telegram отвязан от твоего Minecraft-профиля."
                                    : "NotifyRED: у твоего профиля не было привязанного Telegram."
                    ), false);
                    return 1;
                }))
                .then(Commands.literal("status").executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    boolean linked = TelegramService.isLinked(player.getUUID());
                    context.getSource().sendSuccess(() -> Component.literal(
                            linked ? "NotifyRED: Telegram привязан к твоему профилю."
                                    : "NotifyRED: Telegram пока не привязан. Используй /notifyred link."
                    ), false);
                    return 1;
                }))
        );
    }
}
