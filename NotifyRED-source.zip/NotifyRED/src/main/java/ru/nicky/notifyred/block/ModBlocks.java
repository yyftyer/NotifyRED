package ru.nicky.notifyred.block;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.nicky.notifyred.NotifyRED;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(NotifyRED.MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(NotifyRED.MOD_ID);

    public static final DeferredBlock<RedstoneNotifyBlock> REDSTONE_NOTIFY = BLOCKS.register(
            "redstone_notify",
            () -> new RedstoneNotifyBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.METAL)
                            .strength(2.5F)
            )
    );

    public static final DeferredItem<BlockItem> REDSTONE_NOTIFY_ITEM = ITEMS.registerSimpleBlockItem("redstone_notify", REDSTONE_NOTIFY);

    private ModBlocks() {
    }
}
