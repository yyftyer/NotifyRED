package ru.nicky.notifyred.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import ru.nicky.notifyred.telegram.TelegramService;

public final class RedstoneNotifyBlock extends Block implements EntityBlock {
    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

    public RedstoneNotifyBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(POWERED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RedstoneNotifyBlockEntity(pos, state);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);

        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof RedstoneNotifyBlockEntity notifyEntity && placer instanceof Player player) {
            notifyEntity.setOwner(player.getUUID());
        }

        // Also handles placing the block directly next to an already-powered circuit.
        updateRedstoneState(level, pos);
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock,
                                   BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        updateRedstoneState(level, pos);
    }

    private void updateRedstoneState(Level level, BlockPos pos) {
        if (level.isClientSide) {
            return;
        }

        BlockState currentState = level.getBlockState(pos);
        if (!currentState.hasProperty(POWERED)) {
            return;
        }

        boolean hasSignal = level.hasNeighborSignal(pos);
        boolean wasPowered = currentState.getValue(POWERED);
        if (hasSignal == wasPowered) {
            return;
        }

        level.setBlock(pos, currentState.setValue(POWERED, hasSignal), Block.UPDATE_ALL);

        // Notify only on the rising edge: OFF -> ON. Turning the signal off is silent.
        if (hasSignal && level instanceof ServerLevel serverLevel) {
            BlockEntity blockEntity = serverLevel.getBlockEntity(pos);
            if (blockEntity instanceof RedstoneNotifyBlockEntity notifyEntity && notifyEntity.getOwner() != null) {
                TelegramService.sendActivation(serverLevel, pos, notifyEntity.getOwner());
            }
        }
    }
}
