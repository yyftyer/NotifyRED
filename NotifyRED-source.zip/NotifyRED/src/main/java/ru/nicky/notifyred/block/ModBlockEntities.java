package ru.nicky.notifyred.block;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;
import ru.nicky.notifyred.NotifyRED;

import java.util.function.Supplier;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, NotifyRED.MOD_ID);

    public static final Supplier<BlockEntityType<RedstoneNotifyBlockEntity>> REDSTONE_NOTIFY =
            BLOCK_ENTITY_TYPES.register("redstone_notify", () ->
                    BlockEntityType.Builder.of(
                            RedstoneNotifyBlockEntity::new,
                            ModBlocks.REDSTONE_NOTIFY.get()
                    ).build(null)
            );

    private ModBlockEntities() {
    }
}
