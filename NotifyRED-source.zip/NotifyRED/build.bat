@echo off
chcp 65001 >nul
echo Сборка NotifyRED...
gradle build --no-daemon
if errorlevel 1 (
  echo.
  echo Сборка завершилась с ошибкой. Смотри текст выше.
  pause
  exit /b 1
)
echo.
echo Готово! JAR находится в build\libs\
pause
